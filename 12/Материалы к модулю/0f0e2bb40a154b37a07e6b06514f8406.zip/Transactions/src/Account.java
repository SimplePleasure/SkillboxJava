/**
 * Created by Danya on 18.02.2016.
 */
public class Account
{
    private long money;
    private String accNumber;
}
